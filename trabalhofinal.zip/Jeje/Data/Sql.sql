CREATE DATABASE labprog;
USE labprog;
-- Criação da tabela "users"
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255),
  email VARCHAR(255),
  password VARCHAR(255),
  user_type VARCHAR(255)
);

-- Criação da tabela "categories"
CREATE TABLE categories (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255)
);

-- Criação da tabela "events"
CREATE TABLE events (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(255),
  description TEXT,
  date DATE,
  time TIME,
  location VARCHAR(255),
  category_id INT,
  price DECIMAL(10,2),
  images VARCHAR(255),
  FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Criação da tabela "registrations"
CREATE TABLE registrations (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  event_id INT,
  payment_status VARCHAR(255),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (event_id) REFERENCES events(id)
);

-- Criação da tabela "reviews"
CREATE TABLE reviews (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  event_id INT,
  score INT,  
  comment TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (event_id) REFERENCES events(id)
);


INSERT INTO `users` (`name`, `email`, `password`, `user_type`) 
VALUES ('Pessoal', 'pessoal@pessoal.com', 'pessoal12345', 'pessoal');

INSERT INTO `users` (`name`, `email`, `password`, `user_type`) 
VALUES ('Admin', 'admin@admin.com', 'admin12345', 'admin');

INSERT INTO `users` (`name`, `email`, `password`, `user_type`) 
VALUES ('Login de Vendas', 'vendas@vendas.com', 'vendas12345', 'vendas');

INSERT INTO `categories` (`name`) VALUES ('Festas universitárias');
INSERT INTO `categories` (`name`) VALUES ('Shows');
INSERT INTO `categories` (`name`) VALUES ('Teatro');

INSERT INTO `events` (`title`, `description`, `date`, `time`, `location`, `category_id`, `price`, `images`) 
VALUES ('Metholoko', 'Festa a fantasia', '2022-10-15', '15:30:00', 'Rio Paranaíba - MG', '1', '50.00', 'https://encurtador.com.br/cdlA5');

INSERT INTO `events` (`title`, `description`, `date`, `time`, `location`, `category_id`, `price`, `images`) 
VALUES ('Meth Férias - 2022/2', 'A última festa do período', '2022-12-17', '15:30:00', 'Rio Paranaíba - MG', '2', '45.00', 'https://encurtador.com.br/axFVZ');

INSERT INTO `events` (`title`, `description`, `date`, `time`, `location`, `category_id`, `price`, `images`) 
VALUES ('Conta Copos', 'Calourada dos alunos', '2023-06-17', '16:00:00', 'Rio Paranaíba - MG', '3', '60.00', 'https://encurtador.com.br/agkAM');

INSERT INTO `events` (`title`, `description`, `date`, `time`, `location`, `category_id`, `price`, `images`) 
VALUES ('Meth Férias - 2023/1', 'A última festa do período', '2023-07-15', '16:00:00', 'Rio Paranaíba - MG', '1', '50.00', 'https://encurtador.com.br/kqH56');