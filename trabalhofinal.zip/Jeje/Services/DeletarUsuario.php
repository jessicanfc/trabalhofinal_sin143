<?php
require_once __DIR__ . '/../Classes/Usuarios.php';
session_start();

$user = null;
if (isset($_SESSION['user'])) {
    $user = unserialize($_SESSION['user']);
}

if (isset($_GET['id'])) {
    $userId = $_GET['id'];
    $userToDelete = Usuarios::getById($userId);

    if ($userToDelete && ($user->getUserType() === 'admin' || $user->getUserType() === 'pessoal')) {
        $userToDelete->deleteById($userId);
        header('Location: ../Pages/paginaAdmin.php');
        exit();
    } else {
        header('Location: ../Services/SemAutorizacao.php');
        exit();
    }
} else {
      header('Location: ../Pages/paginaAdmin.php');
    exit();
}
?>
