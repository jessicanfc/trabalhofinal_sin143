<!DOCTYPE html>
<html>
<head>
    <title>Acesso não autorizado.</title>
    <link rel="stylesheet" type="text/css" href="./CSS/style.css">
</head>
<body>
    <header>
        <h1>METH EVENTOS</h1>
    </header>
    
    <section>
        <h2>Sem Autorização.</h2>
        <p>Desculpe, mas você não tem autorização para adquirir seu ingresso.</p>
    </section>
    
    <footer>
    </footer>
</body>
</html>
