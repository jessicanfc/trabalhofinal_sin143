<?php
session_start();

require_once '../Classes/Usuarios.php';

$user = null;
if (isset($_SESSION['user'])) {
    $user = unserialize($_SESSION['user']);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Detalhes do Evento</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style.css">
    <style>
        .event-details {
            max-width: 800px;
            margin: 0 auto;
            margin-top: 50px;
            padding: 20px;
            border: 1px solid;
            border-color: rgb(155, 108, 108);
            border-radius: 15px;
            text-align: center;
        }

        .event-details img {
            width: 100%;
            max-width: 500px;
            height: auto;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <header>
        <h1>METH EVENTOS</h1>
    </header>
    <nav>
        <ul>
            <li><a href="../home.php">Início</a></li>
            <?php if ($user instanceof Usuarios && in_array($user->getUserType(), ['admin', 'pessoal'])) : ?>
                <li><a href="../Pages/adicionarEventos.php">Adicionar Evento</a></li>
            <?php endif; ?>
            <?php if ($user instanceof Usuarios) : ?>
                <li><a href="../Pages/paginaDeInscricaoDeEventos.php">Cadastrar Evento</a></li>
                <li><a href="../Pages/perfil.php">Perfil</a></li>
                <li><a href="../Services/Deslogar.php">Sair</a></li>
            <?php else : ?>
                <li><a href="../Pages/login.php">Login</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    
    <section class="event-details">
        <?php
        require_once __DIR__ . '/../Data/conexao.php';
        require_once '../Classes/Eventos.php';


        if (isset($_GET['id'])) {
            $eventId = $_GET['id'];
            $event = Eventos::getById($eventId);

            if ($event) {
                echo "<h2>{$event->getTitle()}</h2>";
                echo "<img src='{$event->getImages()}' alt='Event Image'>";
                echo "<p>Description: {$event->getDescription()}</p>";
                echo "<p>Date: {$event->getDate()}</p>";
                echo "<p>Time: {$event->getTime()}</p>";
                echo "<p>Location: {$event->getLocation()}</p>";
                echo "<form action='../Pages/paginaDeInscricaoDeEventos.php' method='post'>";
                echo "<input type='hidden' name='event_id' value='{$eventId}'>";
                echo "<input type='submit' name='payment' value='Fazer Inscrição'>";
                echo "</form>";
            } else {
                echo "<p>Não há eventos</p>";
            }
        } else {
            echo "<p>Id Inválido</p>";
        }
        ?>
    </section>
    <br>
    
</body>
</html>