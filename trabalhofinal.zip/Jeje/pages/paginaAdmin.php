<?php
require_once __DIR__ . '/../Classes/Usuarios.php';

session_start();

$user = null;
if (isset($_SESSION['user'])) {
    $user = unserialize($_SESSION['user']);
}

if (!isset($_SESSION['user']) || ($user->getUserType() !== 'admin' && $user->getUserType() !== 'pessoal')) {
    header('Location: ../Services/SemAutorizacao.php');
    exit();
}

if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $users = Usuarios::getUsers($search);
} else {
    $users = Usuarios::getUsers();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Administrador</title>
    <link rel="stylesheet" href="../CSS/style.css">
    <link rel="stylesheet" href="../CSS/paginaAdmin.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <header>
        <h1>METH EVENTOS</h1>
    </header>
    
    <nav>
        <ul>
            <li><a href="../home.php">Início</a></li>
            <?php if ($user instanceof Usuarios && ($user->getUserType() === 'admin' || $user->getUserType() === 'pessoal')) : ?>
                <li><a href="../Pages/adicionarEventos.php">Adicionar Evento</a></li>
            <?php endif; ?>
            <?php if ($user instanceof Usuarios) : ?>
                <li><a href="../Pages/paginaDeInscricaoDeEventos.php">Cadastrar Evento</a></li>
                <li><a href="../Pages/perfil.php">Perfil</a></li>
                <li><a href="../Services/Deslogar.php">Sair</a></li>
            <?php else : ?>
                <li><a href="../Pages/login.php">Login</a></li>
            <?php endif; ?>
        </ul>
    </nav>

    <h1>Usuários</h1>

    <form action="./paginaAdmin.php" method="get">
        <input type="text" name="search" placeholder="Pesquisar por nome">
        <button type="submit">Pesquisar</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>E-mail</th>
                <th>Permissão</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
            <tr>
                <td><?php echo $user->getName(); ?></td>
                <td><?php echo $user->getEmail(); ?></td>
                <td><?php echo $user->getUserType(); ?></td>
                <td>
                    <a href="./editarUsuario?id=<?php echo $user->getId(); ?>">Editar</a>
                    <a href="../Services/DeletarUsuario.php?id=<?php echo $user->getId(); ?>">Excluir</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <h2>Lista de Eventos</h2>
    <a href="./listaDeEventos.php">Ver Lista de Eventos</a>
    
</body>
</html>
