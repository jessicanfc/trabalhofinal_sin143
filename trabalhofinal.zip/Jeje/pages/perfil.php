<?php
session_start();
require_once '../Classes/Usuarios.php';
require_once '../Classes/RegistrarEventos.php';

$user = null;
if (isset($_SESSION['user'])) {
    $user = unserialize($_SESSION['user']);
}

$registeredEvents = [];
if ($user) {
    $registeredEvents = Registrar::getRegisteredEvents($user->getId());
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Perfil do Usuário</title>
    <link rel="stylesheet" type="text/css" href="../CSS/style.css">
    <link rel="stylesheet" type="text/css" href="../CSS/perfil.css">
</head>
<body>
    <header>
        <h1>METH EVENTOS</h1>
    </header>
    
    <nav>
        <ul>
            <li><a href="../home.php">Início</a></li>
            <?php if ($user instanceof Usuarios && ($user->getUserType() === 'admin' || $user->getUserType() === 'pessoal')) : ?>
                <li><a href="../Pages/adicionarEventos.php">Adicionar Evento</a></li>
            <?php endif; ?>
            <?php if ($user instanceof Usuarios) : ?>
                <li><a href="../Pages/paginaDeInscricaoDeEventos.php">Registrar Evento</a></li>
                <li><a href="../Pages/perfil.php">Perfil</a></li>
                <li><a href="../Services/Deslogar.php">Sair</a></li>
            <?php else : ?>
                <li><a href="../Pages/login.php">Login</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    
    <section>
            <div class="user-profile">
                <h2>Perfil</h2>
                <?php if ($user) : ?>
                    <p>Nome: <?php echo $user->getName(); ?></p>
                    <p>E-mail: <?php echo $user->getEmail(); ?></p>
                    <p>Permissão: <?php echo $user->getUserType(); ?></p>
                    <?php if ($user instanceof Usuarios && $user->getUserType() === 'admin') : ?>
                        <a href="./paginaAdmin.php">Administrador</a>
                    <?php endif; ?>
                    <?php if ($user instanceof Usuarios && $user->getUserType() === 'admin') : ?>
                        <div id="admin">
                            <a href="./listaDeEventos.php">Lista de Eventos</a>
                        </div>
                <?php endif; ?>
            </div>    
            <br>
            <h3>Eventos</h3>
            <?php if (!empty($registeredEvents)) : ?>
                <table>
                    <thead>
                        <tr>
                            <th>Nome:</th>
                            <th>Data:</th>
                            <th>Feedbacks:</th>
                            <th>Excluir:</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($registeredEvents as $event) : ?>
                            <tr>
                                <td><?php echo $event->getTitle(); ?></td>
                                <td><?php echo $event->getDate(); ?></td>
                                <td><a href="./comentarios.php?event_id=<?php echo $event->getId(); ?>">Feedbacks</a></td>
                                <td>
                                    <form action="../Services/DeletarEventos.php" method="post">
                                        <input type="hidden" name="event_id" value="<?php echo $event->getId(); ?>">
                                        <button type="submit">Excluir</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else : ?>
                <p>Evento indisponível.</p>
            <?php endif; ?>
        <?php else : ?>
            <p>Você não está logado!</p>
        <?php endif; ?>
    </section>

</body>
</html>
